
if 0
clear all

load('/Users/Luis/Mis_cosas/01_Documents_LCSB/10_MRI_for_PD/Code/My_Code/FVandLinearRef_for_classif/FeatureVector_Prec2mm_Vox3_MinVox36_Vers4_NumROIs34_Imag1_to140.mat')
load Other_info_exp.mat
labels_pop=labels;
end;

% To extract all (or some) ROIs for a specific subject
graphDraw=0;

if 1
for i_dum=1:1
    ROIs_chosen=1:34;
    ROIs_chosen=[1,3,7,8,10,12,13,15,19,21,23,25,27,29,33];
    %ROIs_chosen=1;
    subjects=1;
    dim_feat=1:3;
    num_subjects=140;
    color_for_each_subj=0;
    color_for_each_roi=1;
    index_lab=1;
    
    index_dim=1:(24*max(dim_feat));
    
    inputX=[];
    labels=[];
    
    for i_r=1:length(ROIs_chosen)
        
        aux=feature_vector_for_all_ROIs_and_images{1,ROIs_chosen(i_r)};
        aux=aux(index_dim,:);
        
        number_subr=size(aux,2)/num_subjects;
        
        index_subr=[];
        for i_s=1:length(subjects)
            
            index_subr=[index_subr,((subjects(i_s)-1)*number_subr+1)...
                :(subjects(i_s)*number_subr)];
            
            labels=[labels,ones(1,number_subr)*index_lab];
            
            if color_for_each_subj==1
                index_lab=index_lab+1;
            end;
            
        end;
        
        inputX=[inputX,aux(:,index_subr)];
        
        if color_for_each_roi==0
            index_lab=1;
        elseif color_for_each_roi==1 && color_for_each_subj==0
            index_lab=index_lab+1;
        end;
        
    end;
    
    inputX=inputX';
    
    if max(dim_feat)>1
        val1=30;
    else
        val1=20;
    end;
    
    %mappedX=tsne(inputX,labels,3,val1,val1);
    
    % mappedX = fast_tsne(X, initial_dims, perplexity, theta)
    % defaults => initial_dims=50 / perplexity=30 / theta=0.5
    
    % mappedX = fast_tsne(inputX); % bh-tsne
end;
end;

% To extract for some ROIs separating the populations

if 0
ROIs_chosen=[8,10];
for i_dum1=1:1
    
    
    subjects=1:100;
    dim_feat=1:3;
    num_subjects=140;
    color_for_each_roi=1;
    index_lab=1;
    
    index_dim=1:(24*max(dim_feat));
    
    inputX=[];
    labels=[];
    
    for i_r=1:length(ROIs_chosen)
        
        aux=feature_vector_for_all_ROIs_and_images{1,ROIs_chosen(i_r)};
        aux=aux(index_dim,:);
        
        number_subr=size(aux,2)/num_subjects;
        
        index_subr=[];
        for i_s=1:length(subjects)
            
            index_subr=[index_subr,((subjects(i_s)-1)*number_subr+1)...
                :(subjects(i_s)*number_subr)];
            
            if labels_pop(subjects(i_s))==-1
                aux_index=index_lab;
            else
                aux_index=index_lab+1;
            end;
            labels=[labels,ones(1,number_subr)*aux_index];
            
        end;
        
        inputX=[inputX,aux(:,index_subr)];
        
        if color_for_each_roi==1
            index_lab=index_lab+2;
        end;
        
    end;
    
    inputX=inputX';
    
    if max(dim_feat)>1
        val1=30;
    else
        val1=20;
    end;
    
    %mappedX=tsne(inputX,labels,3,val1,val1);
    %[mappedX,landmarks,costs]=fast_tsne(inputX,3,val1);
    
    % mappedX = fast_tsne(X, initial_dims, perplexity, theta)
    % defaults => initial_dims=50 / perplexity=30 / theta=0.5
    
    %mappedX = fast_tsne(inputX,50); % bh-tsne
end;
end;

% To extract some ROIs for all the subjects, or a specific subset

if 0
ROIs_chosen=[1,25,29];
subjects=1:140;
dim_feat=1:3;
end;

% To draw each of the labels

if graphDraw==1
    
    marks={'yo','mo','co','ro','go','bo','ko',...
        'yx','mx','cx','rx','gx','bx','kx',...
        'ys','ms','cs','rs','gs','bs','ks'};
for i_l=1:max(labels)
   
    aux_ind=find(labels==i_l);
    scatter(mappedX(aux_ind,1), mappedX(aux_ind,2),9,marks{1,i_l});
    hold on;
end;

legend(num2str(unique(labels)'));
end;