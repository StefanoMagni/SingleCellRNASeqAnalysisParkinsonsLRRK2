

no_dims=2;
run ./bh_tsne/extraction_features_tSNE.m
method='LMNN';

% List of methods
% Principal Component Analysis (PCA)
% ? Probabilistic PCA
% ? Factor Analysis (FA)
% ? Classical multidimensional scaling (MDS)
% ? Sammon mapping
% ? Linear Discriminant Analysis (LDA)
% ? Isomap
% ? Landmark Isomap
% ? Local Linear Embedding (LLE)
% ? Laplacian Eigenmaps
% ? Hessian LLE
% ? Local Tangent Space Alignment (LTSA)
% ? Conformal Eigenmaps (extension of LLE)
% ? Maximum Variance Unfolding (extension of LLE)
% ? Landmark MVU (LandmarkMVU)
% ? Fast Maximum Variance Unfolding (FastMVU)
% ? Kernel PCA
% ? Generalized Discriminant Analysis (GDA)
% ? Diffusion maps
% ? Neighborhood Preserving Embedding (NPE)
% ? Locality Preserving Projection (LPP)
% ? Linear Local Tangent Space Alignment (LLTSA)
% ? Stochastic Proximity Embedding (SPE)
% ? Deep autoencoders (using denoising autoencoder pretraining)
% ? Local Linear Coordination (LLC)
% ? Manifold charting
% ? Coordinated Factor Analysis (CFA)
% ? Gaussian Process Latent Variable Model (GPLVM)
% ? Stochastic Neighbor Embedding (SNE)
% ? Symmetric SNE
% ? t-Distributed Stochastic Neighbor Embedding (t-SNE)
% ? Neighborhood Components Analysis (NCA)
% ? Maximally Collapsing Metric Learning (MCML)
% ? Large-Margin Nearest Neighbor (LMNN)
%
% Names for methods and additional parameters
%     PCA:            - none
%     LDA:            - none
%     MDS:            - none
%     ProbPCA:        - <int> max_iterations -> default = 200
%     FactorAnalysis: - none
%     GPLVM:          - <double> sigma -> default = 1.0
%     Sammon:         - none
%     Isomap:         - <int> k -> default = 12
%     LandmarkIsomap: - <int> k -> default = 12
%                     - <double> percentage -> default = 0.2
%     LLE:            - <int> k -> default = 12
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     Laplacian:      - <int> k -> default = 12
%                     - <double> sigma -> default = 1.0
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     HessianLLE:     - <int> k -> default = 12
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     LTSA:           - <int> k -> default = 12
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     MVU:            - <int> k -> default = 12
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     CCA:            - <int> k -> default = 12
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     LandmarkMVU:    - <int> k -> default = 5
%     FastMVU:        - <int> k -> default = 5
%                     - <logical> finetune -> default = true
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     DiffusionMaps:  - <double> t -> default = 1.0
%                     - <double> sigma -> default = 1.0
%     KernelPCA:      - <char[]> kernel -> {'linear', 'poly', ['gauss']} 
%                     - kernel parameters: type HELP GRAM for info
%     GDA:            - <char[]> kernel -> {'linear', 'poly', ['gauss']} 
%                     - kernel parameters: type HELP GRAM for info
%     SNE:            - <double> perplexity -> default = 30
%     SymSNE:         - <double> perplexity -> default = 30
%     tSNE:           - <int> initial_dims -> default = 30
%                     - <double> perplexity -> default = 30
%     LPP:            - <int> k -> default = 12
%                     - <double> sigma -> default = 1.0
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     NPE:            - <int> k -> default = 12
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     LLTSA:          - <int> k -> default = 12
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     SPE:            - <char[]> type -> {['Global'], 'Local'}
%                     - if 'Local': <int> k -> default = 12
%     Autoencoder:    - <double> lambda -> default = 0
%     LLC:            - <int> k -> default = 12
%                     - <int> no_analyzers -> default = 20
%                     - <int> max_iterations -> default = 200
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     ManifoldChart:  - <int> no_analyzers -> default = 40
%                     - <int> max_iterations -> default = 200
%                     - <char[]> eig_impl -> {['Matlab'], 'JDQR'}
%     CFA:            - <int> no_analyzers -> default = 2
%                     - <int> max_iterations -> default = 200
%     NCA:            - <double> lambda -> default = 0.0
%     MCML:           - none
%     LMNN:           - <int> k -> default = 3

a=tic;
[mappedX, mapping] = compute_mapping(inputX,method, no_dims);
time=toc(a);

figure, scatter(mappedX(:,1), mappedX(:,2), 5, labels); title(['Result of ' method]);
text(min(mappedX(:,1)),max(mappedX(:,2)),['CPU Time = ' num2str(time)]);
no_dims = round(intrinsic_dim(inputX, 'MLE'))
