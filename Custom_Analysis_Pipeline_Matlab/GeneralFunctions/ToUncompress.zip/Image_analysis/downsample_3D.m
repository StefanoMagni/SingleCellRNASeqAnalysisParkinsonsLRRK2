
% An easy snippet for downsampling a 3D image in the X-Y direction
function image_down=downsample_3D(image,scale_xy)

image_down=[];
if nargin==1
    scale_xy=[0.5,0.5];
end;

for i=1:size(image,3)
    image_down(:,:,i)=imresize(image(:,:,i),[ceil(size(image,1)*scale_xy(1)),...
        ceil(size(image,2)*scale_xy(2))]);
end;