function varargout = vis_Slides_withThandOVerlay(varargin)
% VIS_SLIDES_WITHTHANDOVERLAY MATLAB code for vis_Slides_withThandOVerlay.fig
%      VIS_SLIDES_WITHTHANDOVERLAY, by itself, creates a new VIS_SLIDES_WITHTHANDOVERLAY or raises the existing
%      singleton*.
%
%      H = VIS_SLIDES_WITHTHANDOVERLAY returns the handle to a new VIS_SLIDES_WITHTHANDOVERLAY or the handle to
%      the existing singleton*.
%
%      VIS_SLIDES_WITHTHANDOVERLAY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VIS_SLIDES_WITHTHANDOVERLAY.M with the given input arguments.
%
%      VIS_SLIDES_WITHTHANDOVERLAY('Property','Value',...) creates a new VIS_SLIDES_WITHTHANDOVERLAY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before vis_Slides_withThandOVerlay_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to vis_Slides_withThandOVerlay_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help vis_Slides_withThandOVerlay

% Last Modified by GUIDE v2.5 24-Jan-2017 16:10:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @vis_Slides_withThandOVerlay_OpeningFcn, ...
                   'gui_OutputFcn',  @vis_Slides_withThandOVerlay_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before vis_Slides_withThandOVerlay is made visible.
function vis_Slides_withThandOVerlay_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to vis_Slides_withThandOVerlay (see VARARGIN)

% Choose default command line output for vis_Slides_withThandOVerlay
handles.output = hObject;

% Other stuff initialized
handles.text2.UserData=0;
handles.menu_base_image.String=evalin('base','who');
handles.menu_overlay_image.String=evalin('base','who');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes vis_Slides_withThandOVerlay wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = vis_Slides_withThandOVerlay_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function overlay_image_Callback(hObject, eventdata, handles)
% hObject    handle to overlay_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of overlay_image as text
%        str2double(get(hObject,'String')) returns contents of overlay_image as a double


% --- Executes during object creation, after setting all properties.
function overlay_image_CreateFcn(hObject, eventdata, handles)
% hObject    handle to overlay_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function threshold_Callback(hObject, eventdata, handles)
% hObject    handle to threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of threshold as text
%        str2double(get(hObject,'String')) returns contents of threshold as a double
plot_function(handles)

% --- Executes during object creation, after setting all properties.
function threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function number_slice_Callback(hObject, eventdata, handles)
% hObject    handle to number_slice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of number_slice as text
%        str2double(get(hObject,'String')) returns contents of number_slice as a double
plot_function(handles)

% --- Executes during object creation, after setting all properties.
function number_slice_CreateFcn(hObject, eventdata, handles)
% hObject    handle to number_slice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in menu_base_image.
function menu_base_image_Callback(hObject, eventdata, handles)
% hObject    handle to menu_base_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns menu_base_image contents as cell array
%        contents{get(hObject,'Value')} returns selected item from menu_base_image
stop=1;
string_vars=get(hObject,'String');
var_selected=string_vars{get(hObject,'Value')};
slice_selected=handles.number_slice.String;
evalin('base',['imagesc(' var_selected '(:,:,' slice_selected '))'])

% --- Executes during object creation, after setting all properties.
function menu_base_image_CreateFcn(hObject, eventdata, handles)
% hObject    handle to menu_base_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in menu_overlay_image.
function menu_overlay_image_Callback(hObject, eventdata, handles)
% hObject    handle to menu_overlay_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns menu_overlay_image contents as cell array
%        contents{get(hObject,'Value')} returns selected item from menu_overlay_image
string_vars=get(hObject,'String');
var_selected=string_vars{get(hObject,'Value')};
slice_selected=handles.number_slice.String;
var_selected_base=handles.menu_base_image.Value;
var_selected_base_str=handles.menu_base_image.String;
var_selected_base=var_selected_base_str{var_selected_base};
if handles.text2.UserData==0
    mask_sel=evalin('base',var_selected);
    if max(mask_sel(:))>1
        mask_sel=double(mask_sel);
        mask_sel=mask_sel/max(mask_sel(:));
        evalin('base',[var_selected '=double(' var_selected ');']);
        evalin('base',[var_selected '=' var_selected '/max(' var_selected '(:));']);
    end;
    level=graythresh(mask_sel(:,:,slice_selected));
    %level=graythresh(mask_sel);
    handles.threshold.String=level;
    handles.menu_overlay_image.UserData=size(mask_sel,3);
    handles.text2.UserData=1;
end;

evalin('base',['imagesc(imoverlay(' var_selected_base '(:,:,' slice_selected...
    ')/max(' var_selected_base '(:)),bwperim((' var_selected '(:,:,' slice_selected ')>' num2str(level) ')),[1,0,0]))']);

% --- Executes during object creation, after setting all properties.
function menu_overlay_image_CreateFcn(hObject, eventdata, handles)
% hObject    handle to menu_overlay_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in down_button.
function down_button_Callback(hObject, eventdata, handles)
% hObject    handle to down_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if str2num(handles.number_slice.String)==1
    handles.number_slice.String=handles.menu_overlay_image.UserData;
else
    handles.number_slice.String=num2str(str2num(handles.number_slice.String)-1);
end;
plot_function(handles)

% --- Executes on button press in up_button.
function up_button_Callback(hObject, eventdata, handles)
% hObject    handle to up_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if str2num(handles.number_slice.String)==handles.menu_overlay_image.UserData
    handles.number_slice.String=num2str(1);
else
    handles.number_slice.String=num2str(str2num(handles.number_slice.String)+1);
end;
plot_function(handles)

% --- Executes on button press in down_buttonx2.
function down_buttonx2_Callback(hObject, eventdata, handles)
% hObject    handle to down_buttonx2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if str2num(handles.number_slice.String)==2
    handles.number_slice.String=handles.menu_overlay_image.UserData;
elseif str2num(handles.number_slice.String)==1
    handles.number_slice.String=handles.menu_overlay_image.UserData-1;
else
    handles.number_slice.String=num2str(str2num(handles.number_slice.String)-2);
end;
plot_function(handles)

% --- Executes on button press in up_buttonx2.
function up_buttonx2_Callback(hObject, eventdata, handles)
% hObject    handle to up_buttonx2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if str2num(handles.number_slice.String)==handles.menu_overlay_image.UserData
    handles.number_slice.String=num2str(2);
elseif str2num(handles.number_slice.String)==(handles.menu_overlay_image.UserData-1)
    handles.number_slice.String=num2str(1);
else
    handles.number_slice.String=num2str(str2num(handles.number_slice.String)+2);
end;
plot_function(handles)

function plot_function(handles)

var_selected=handles.menu_overlay_image.Value;
var_selected_str=handles.menu_overlay_image.String;
var_selected=var_selected_str{var_selected};

var_selected_base=handles.menu_base_image.Value;
var_selected_base_str=handles.menu_base_image.String;
var_selected_base=var_selected_base_str{var_selected_base};

slice_selected=handles.number_slice.String;
threshold=handles.threshold.String;

evalin('base',['imagesc(imoverlay(' var_selected_base '(:,:,' slice_selected...
    ')/max(' var_selected_base '(:)),bwperim((' var_selected '(:,:,' slice_selected ') >' num2str(threshold) ')), [1,0,0]))']);

