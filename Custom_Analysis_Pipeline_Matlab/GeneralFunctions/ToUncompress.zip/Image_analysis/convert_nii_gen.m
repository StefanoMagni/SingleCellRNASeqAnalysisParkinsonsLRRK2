
% A simple function to convert any file to nifti, consider a standard
% header with the following parameters:
% voxel_size=[1,1,1], origins=[0,0,0];

function convert_nii_gen(image,filename,scale_xy)

if length(size(image))==3
    image=reshape(image,size(image,1),size(image,2),1,size(image,3));
end;

if nargin==1
    filename='image_nifti.nii.gz';
    scale_xy=[];
elseif nargin==2
    scale_xy=[];
end;

if ~isempty(scale_xy)
    image=downsample_3D(image,scale_xy);
end;

%%%%%
% Parameters NifTi
filetype=2;
% 2 - uint8,  4 - int16,  8 - int32,  16 - float32,
% 32 - complex64,  64 - float64,  128 - RGB24,
% 256 - int8,  511 - RGB96,  512 - uint16,
% 768 - uint32,  1792 - complex128
% Default will use the data type of 'img' matrix
% For RGB image, you must specify it to either 128
% or 511.
voxel_size=[1,1,1];
origins=[0,0,0];

%%%%%

nii=make_nii(image,voxel_size,origins);

save_nii(nii,filename,0);


