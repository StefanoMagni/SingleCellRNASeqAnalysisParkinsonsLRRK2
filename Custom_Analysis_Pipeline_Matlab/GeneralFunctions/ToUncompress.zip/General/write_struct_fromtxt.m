
function all_files_feat=write_struct_fromtxt(name_txt_files)

fid=fopen(name_txt_files,'r');

all_files_feat={};
not_end=1;
count_col=1;
count_row=1;
while not_end    
    
    chain = fgets(fid);
    if ischar(chain)
        chain=cellstr(chain);
        chain=chain{1,1};
    end;
    
    if isempty(chain)
        count_col=count_col+1;
        count_row=1;
    elseif chain==-1
            not_end=0;      
    else
        all_files_feat{count_row,count_col}=chain;
        count_row=count_row+1;
        
    end;

end;